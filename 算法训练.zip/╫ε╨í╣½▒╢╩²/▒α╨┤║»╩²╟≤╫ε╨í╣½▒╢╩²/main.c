#include <stdio.h>

int lcm(int n,int m){
	int tmp;
	if(m==0){
		return n;
	}
	else{
		lcm(m,n%m);
	}
}

int main(){
	int n,m;
	while(scanf("%d%d",&n,&m)!=EOF){
		printf("%d\n",(n*m)/lcm(n,m));
	}
	return 0;
}
