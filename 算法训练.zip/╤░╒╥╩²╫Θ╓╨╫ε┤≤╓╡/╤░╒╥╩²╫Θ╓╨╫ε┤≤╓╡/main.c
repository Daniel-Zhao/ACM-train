#include <stdio.h>
#define MaxSize 100+5

main()
{
	int a[MaxSize],n;
	int i,flag,max;

	scanf("%d",&n);
	for(i=0;i<n;i++)
	{

		scanf("%d",&a[i]);
		if(i==0)
		{
			max=a[i];
			flag=i;
		}

		if(a[i]>max)
		{
			max=a[i];
			flag=i;
		}
	}

	printf("%d %d\n",max,flag);

	return 0;
}
