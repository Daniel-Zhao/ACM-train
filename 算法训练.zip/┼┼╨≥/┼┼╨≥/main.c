#include<stdio.h>
int main()
{
    int n,m,l,tmp;
    scanf("%d%d%d",&n,&m,&l);
    if(n<m)
    {
        tmp=n;
        n=m;
        m=tmp;
    }
    if(n<l)
    {
        tmp=n;
        n=l;
        l=tmp;
    }
    if(m<l)
    {
        tmp=m;
        m=l;
        l=tmp;
    }
    printf("%d %d %d\n",n,m,l);
    return 0;
}
