#include <stdio.h>
#define MaxSize 8+5

//��������-���дӴ�С
void BubbleSort(int num[],int Size)
{
	int i,j;
	int temp;

	for(i=Size-1;i>0;i--)
	{
		for(j=0;j<i;j++)
		{
			if(num[j]<num[j+1])
			{
				temp=num[j];
				num[j]=num[j+1];
				num[j+1]=temp;
			}
		}
	}
}
main()
{
	int T,n,i;
	int a[MaxSize],b[MaxSize];

	scanf("%d",&T);
	while(T--)
	{
		int sum=0;

		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++)
		{
			scanf("%d",&b[i]);
		}

		//�����С����
		BubbleSort(a,n);
		BubbleSort(b,n);

		for(i=0;i<n;i++)
		{
			sum+=a[i]*b[n-1-i];
		}

		printf("%d\n",sum);
	}

	return 0;
}
