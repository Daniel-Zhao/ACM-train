#include "stdio.h"
int arr[2100]={0} ;
void New()
{
    int i ;
    for(i=1;;i++)
    {
        if(arr[i]==0)
        {
            printf("%d\n",i);
            arr[i]=1 ;
            break ;
        }
    }
}
void Delete(char str[])
{
    int count=0 ;
    char*p=&str[7];
    while(*p)
    {
        if(*p>='0'&&*p<='9')
        {
            count=count*10+*p-'0' ;
        }
        p++;
    }
    if(arr[count]==1)
    {
        arr[count]=0 ;
        printf("Successful\n");
    }
    else
    {
        printf("Failed\n");
    }
}
int main()
{
    char str[20];
    char*p ;
    int n,i ;
    scanf("%d",&n);
    getchar();
    for(i=0;i<n;i++)
    {
        gets(str);
        p=str ;
        if(*p=='N')
        {
            New();
        }
        if(*p=='D')
        {
            Delete(str);
        }
    }
    return 0 ;
}
