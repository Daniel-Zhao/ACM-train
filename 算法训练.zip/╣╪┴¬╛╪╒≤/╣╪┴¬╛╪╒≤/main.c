#include<stdio.h>
int main()
{
	int i, ii,n,m, a[1000][2];
	scanf("%d%d", &n, &m);

	for (  i = 0; i < m; i++)
	scanf("%d%d", &a[i][0], &a[i][1]);
	for ( i = 1; i <=n; i++)
	{
		for (ii = 0; ii < m; ii++)
		{
			if (i==a[ii][0])
			{
				printf("1 ");
			}
			else
			if (i==a[ii][1])
			{
				printf("-1 ");
			}
			else
			{
				printf("0 ");
			}
		}
		printf("\n");
	}

	return 0;
}
