#include <stdio.h>
#include <string.h>

int main(void)
{
    char c;
    int n,m;
    scanf("%c",&c);
    scanf("%d%d",&n,&m);
    if(c=='+')
    {
        printf("%d\n",n+m);
    }
    if(c=='-')
    {
        printf("%d\n",n-m);
    }
    if(c=='*')
    {
        printf("%d\n",n*m);
    }
    if(c=='/')
    {
        printf("%d\n",n/m);
    }
 return 0;
}
