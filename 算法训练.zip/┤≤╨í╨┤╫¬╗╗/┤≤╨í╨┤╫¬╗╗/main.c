#include <stdio.h>
#include <stdlib.h>
#define MAX 20
int main()
{
    int i=0;
    char ch[MAX];
    gets(ch);
    do
    {
        if(ch[i]>='a'&&ch[i]<='z')
            ch[i]-=32;
        else
            ch[i]+=32;
        i++;
    }while(ch[i]!='\0');
    puts(ch);
    return 0;
}
