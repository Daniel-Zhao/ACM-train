#include<stdio.h>
#include<string.h>
#include<ctype.h>
#define MAX 85
char a[MAX];
char b[MAX];
int times[MAX];
void getTimes(char a[],int times[]);
int searchin(char a[],int times[],char b[]);
int main()
{
    int num1,num2,i;
    scanf("%s",a);
    scanf("%s",b);
    if(strlen(a)!=strlen(b))
    {
        printf("N\n");
        return 0;
    }
    //��д��ĸת����Сд��ĸ
    for(i=0;i<strlen(a);i++)
    {
        a[i]=tolower(a[i]);
    }
    for(i=0;i<strlen(b);i++)
    {
        b[i]=tolower(b[i]);
    }
    getTimes(a,times);
    num1=searchin(a,times,b);
    if(num1!=strlen(a))
    {
        printf("N\n");
        return 0;
    }
    getTimes(b,times);
    num2=searchin(b,times,a);
    if(num2!=strlen(b))
    {
        printf("N\n");
        return 0;
    }
    else
    {
        printf("Y\n");
        return 0;
    }
}
